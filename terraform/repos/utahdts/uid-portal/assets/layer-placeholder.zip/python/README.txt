Placeholder layer; application CI publishes dependencies.
