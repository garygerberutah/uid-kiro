def handler(event, context):
    return {'statusCode': 503, 'body': 'Deployment pending'}
